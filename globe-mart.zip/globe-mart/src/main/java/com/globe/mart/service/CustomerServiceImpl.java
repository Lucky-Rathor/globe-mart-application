package com.globe.mart.service;



import com.globe.mart.exception.CustomerException;
import com.globe.mart.model.Customer;
import com.globe.mart.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;


    @Override
    public Customer addCustomer(Customer customer) throws CustomerException {
      Optional<Customer> isCustomerPresent = customerRepository.findById(customer.getCustomerId());
             if (ObjectUtils.isEmpty(customer.getCustomerName()) || isCustomerPresent.isPresent()) {
                 throw new CustomerException("Please provide valid customer details");
             }
             return customerRepository.save(customer);
    }

    @Override
    public Customer updateCustomer(Customer customer) throws CustomerException {
     Optional<Customer> customerOptional = customerRepository.findById(customer.getCustomerId());
     if (customerOptional.isEmpty()) {
         throw new CustomerException("customer with this id"+ customer.getCustomerId()+"does not exist");
     }
     return customerRepository.save(customer);
    }

    @Override
    @Transactional
    public String deleteCustomerById(Integer customerId) throws CustomerException {
        Optional<Customer> customerOptional = customerRepository.findById(customerId);
        if (customerOptional.isEmpty()) {
            throw new CustomerException("customer with this id"+ customerId +"does not exist! can't delete");
        }

         customerRepository.deleteById(customerId);
        return "Customer Deleted Successfully";
    }
}

package com.globe.mart.controller;



import com.globe.mart.exception.CustomerException;
import com.globe.mart.model.Customer;
import com.globe.mart.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping(value = "/customer")
    public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) throws CustomerException {
        Customer newCustomer = customerService.addCustomer(customer);
        return new ResponseEntity<>(newCustomer, HttpStatus.CREATED);
    }

    @PutMapping(value = "/customer/{customerId}")
    public Customer updateCustomer(@PathVariable("customerId") Integer customerId, @RequestBody Customer customer) throws CustomerException {
        return customerService.updateCustomer(customer);
    }

    @DeleteMapping(value = "/customer/{customerId}")
    public String deleteCustomerById(@PathVariable("customerId") Integer customerId) throws CustomerException {
        customerService.deleteCustomerById(customerId);
        return "Customer deleted Successfully with" + " " + customerId;
    }

}

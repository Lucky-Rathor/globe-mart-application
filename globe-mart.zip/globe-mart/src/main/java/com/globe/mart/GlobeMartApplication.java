package com.globe.mart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobeMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobeMartApplication.class, args);
	}

}

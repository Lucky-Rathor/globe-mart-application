package com.globe.mart.exception;

public class ProductException extends Exception {

    public ProductException(String msg) {
        super(msg);
    }
}

package com.globe.mart.service;


import com.globe.mart.exception.CustomerException;
import com.globe.mart.model.Customer;

public interface CustomerService {

     Customer addCustomer(Customer customer) throws CustomerException;

     Customer updateCustomer(Customer customer) throws CustomerException;

     String deleteCustomerById(Integer customerId) throws CustomerException;


}

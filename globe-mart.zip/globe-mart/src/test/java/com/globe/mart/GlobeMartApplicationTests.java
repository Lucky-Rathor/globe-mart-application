package com.globe.mart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobeMartApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
